import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BookOpen, GraduationCap, HelpCircle, Play } from 'lucide-react';
import PM08Questions from '@/sections/PM08Questions';
import PM10Questions from '@/sections/PM10Questions';
import PM09Placeholder from '@/sections/PM09Placeholder';
import PM08Quiz from '@/sections/PM08Quiz';
import PM10Quiz from '@/sections/PM10Quiz';
import type { TabType } from '@/types/questions';

type ViewType = 'list' | 'quiz';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('pm08');
  const [view, setView] = useState<ViewType>('list');

  const handleTabChange = (value: string) => {
    setActiveTab(value as TabType);
    setView('list');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center gap-3 mb-2">
            <GraduationCap className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-slate-900">Экзамены Колледжа</h1>
          </div>
          <p className="text-slate-600 ml-11">
            База вопросов и ответов для подготовки к экзаменам ПМ08, ПМ09, ПМ10
          </p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-blue-800 flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                ПМ08
              </CardTitle>
              <CardDescription className="text-blue-600">
                Интернет вещей и IoT
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-blue-800">240 вопросов</p>
              <p className="text-sm text-blue-600 mt-1">С прямыми ответами</p>
            </CardContent>
          </Card>

          <Card className="bg-amber-50 border-amber-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-amber-800 flex items-center gap-2">
                <HelpCircle className="h-5 w-5" />
                ПМ09
              </CardTitle>
              <CardDescription className="text-amber-600">
                В ожидании данных
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-amber-800">Скоро</p>
              <p className="text-sm text-amber-600 mt-1">Материалы будут добавлены</p>
            </CardContent>
          </Card>

          <Card className="bg-emerald-50 border-emerald-200">
            <CardHeader className="pb-3">
              <CardTitle className="text-emerald-800 flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                ПМ10
              </CardTitle>
              <CardDescription className="text-emerald-600">
                Сетевые технологии
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-emerald-800">241 вопрос</p>
              <p className="text-sm text-emerald-600 mt-1">Тестовый формат</p>
            </CardContent>
          </Card>
        </div>

        {/* View Toggle */}
        <div className="flex justify-end mb-4">
          <div className="flex gap-2 bg-white rounded-lg p-1 border shadow-sm">
            <Button
              variant={view === 'list' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setView('list')}
              className="gap-2"
            >
              <BookOpen className="h-4 w-4" />
              Вопросы
            </Button>
            <Button
              variant={view === 'quiz' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setView('quiz')}
              className="gap-2"
            >
              <Play className="h-4 w-4" />
              Викторина
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={handleTabChange}>
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="pm08">ПМ08 (IoT)</TabsTrigger>
            <TabsTrigger value="pm09">ПМ09</TabsTrigger>
            <TabsTrigger value="pm10">ПМ10 (Сети)</TabsTrigger>
          </TabsList>

          <TabsContent value="pm08">
            {view === 'list' ? <PM08Questions /> : <PM08Quiz />}
          </TabsContent>

          <TabsContent value="pm09">
            <PM09Placeholder />
          </TabsContent>

          <TabsContent value="pm10">
            {view === 'list' ? <PM10Questions /> : <PM10Quiz />}
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6 text-center text-slate-500">
          <p>База вопросов для подготовки к экзаменам. Учебные материалы колледжа.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;
