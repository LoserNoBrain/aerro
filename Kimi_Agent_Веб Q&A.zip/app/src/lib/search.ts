import type { PM08Question, PM10Question } from '@/types/questions';

export function searchPM08(questions: PM08Question[], query: string): PM08Question[] {
  if (!query.trim()) return questions;
  
  const lowerQuery = query.toLowerCase().trim();
  return questions.filter(q => 
    q.question.toLowerCase().includes(lowerQuery) ||
    q.answer.toLowerCase().includes(lowerQuery)
  );
}

export function searchPM10(questions: PM10Question[], query: string): PM10Question[] {
  if (!query.trim()) return questions;
  
  const lowerQuery = query.toLowerCase().trim();
  return questions.filter(q => {
    if (q.question.toLowerCase().includes(lowerQuery)) return true;
    return q.options.some(opt => opt.toLowerCase().includes(lowerQuery));
  });
}

export function highlightText(text: string, query: string): string {
  if (!query.trim()) return text;
  
  const lowerQuery = query.toLowerCase().trim();
  const lowerText = text.toLowerCase();
  
  if (!lowerText.includes(lowerQuery)) return text;
  
  const index = lowerText.indexOf(lowerQuery);
  const before = text.substring(0, index);
  const match = text.substring(index, index + query.length);
  const after = text.substring(index + query.length);
  
  return `${before}<mark class="bg-yellow-200 text-black px-0.5 rounded">${match}</mark>${after}`;
}
