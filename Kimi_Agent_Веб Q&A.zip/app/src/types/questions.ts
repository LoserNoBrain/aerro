export interface PM08Question {
  id: number;
  question: string;
  answer: string;
}

export interface PM10Question {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
}

export type TabType = 'pm08' | 'pm09' | 'pm10';

export interface QuizState {
  currentQuestion: number;
  score: number;
  answered: boolean;
  selectedAnswer: number | null;
  isCorrect: boolean | null;
  showResults: boolean;
  answers: { questionId: number; selected: number; correct: boolean }[];
}
