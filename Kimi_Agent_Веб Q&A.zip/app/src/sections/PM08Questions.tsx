import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Search, ChevronDown, ChevronUp, Eye, EyeOff } from 'lucide-react';
import { usePM08Questions } from '@/hooks/useQuestions';
import { searchPM08 } from '@/lib/search';

export default function PM08Questions() {
  const { questions, loading, error } = usePM08Questions();
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedId, setExpandedId] = useState<number | null>(null);
  const [showAllAnswers, setShowAllAnswers] = useState(false);

  if (loading) return <div className="text-center py-12 text-slate-500">Загрузка вопросов...</div>;
  if (error) return <div className="text-center py-12 text-red-500">Ошибка: {error}</div>;

  const filtered = searchPM08(questions, searchQuery);

  const toggleExpand = (id: number) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <div className="flex gap-2 items-center bg-white p-4 rounded-lg border shadow-sm">
        <Search className="h-5 w-5 text-slate-400 flex-shrink-0" />
        <Input
          placeholder="Поиск по вопросам или ответам..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="flex-1 border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
        />
        {searchQuery && (
          <Button variant="ghost" size="sm" onClick={() => setSearchQuery('')}>
            Очистить
          </Button>
        )}
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowAllAnswers(!showAllAnswers)}
          className="gap-2"
        >
          {showAllAnswers ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
          {showAllAnswers ? 'Скрыть' : 'Показать'} все
        </Button>
      </div>

      {/* Results count */}
      <p className="text-sm text-slate-500">
        Показано {filtered.length} из {questions.length} вопросов
        {searchQuery && ` (по запросу "${searchQuery}")`}
      </p>

      {/* Questions List */}
      <div className="space-y-3">
        {filtered.map((q) => {
          const isExpanded = expandedId === q.id || showAllAnswers;
          
          // Highlight search matches
          let questionHtml = q.question;
          if (searchQuery.trim()) {
            const regex = new RegExp(`(${searchQuery.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
            questionHtml = q.question.replace(regex, '<mark class="bg-yellow-200 text-black px-0.5 rounded">$1</mark>');
          }

          return (
            <Card key={q.id} className={`transition-all ${isExpanded ? 'border-blue-300 shadow-md' : ''}`}>
              <CardHeader className="pb-2 cursor-pointer" onClick={() => toggleExpand(q.id)}>
                <div className="flex justify-between items-start gap-4">
                  <CardTitle className="text-base font-medium leading-relaxed">
                    <span className="text-blue-600 font-bold mr-2">{q.id}.</span>
                    <span dangerouslySetInnerHTML={{ __html: questionHtml }} />
                  </CardTitle>
                  <Button variant="ghost" size="sm" className="flex-shrink-0">
                    {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                  </Button>
                </div>
              </CardHeader>
              
              {isExpanded && (
                <CardContent className="pt-0">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4 mt-2">
                    <p className="text-sm font-semibold text-green-800 mb-1">Ответ:</p>
                    <p className="text-green-900">{q.answer}</p>
                  </div>
                </CardContent>
              )}
            </Card>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 bg-white rounded-lg border">
          <Search className="h-12 w-12 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500">Ничего не найдено по запросу "{searchQuery}"</p>
        </div>
      )}
    </div>
  );
}
