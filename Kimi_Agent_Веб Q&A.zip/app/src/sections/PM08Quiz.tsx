import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Trophy, RotateCcw, Eye, EyeOff, ChevronRight, Star, Zap, BookOpen } from 'lucide-react';
import { usePM08Questions } from '@/hooks/useQuestions';

type QuizPhase = 'ready' | 'playing' | 'results';

interface AnswerRecord {
  questionId: number;
  question: string;
  answer: string;
  revealed: boolean;
}

export default function PM08Quiz() {
  const { questions, loading, error } = usePM08Questions();
  const [phase, setPhase] = useState<QuizPhase>('ready');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [answers, setAnswers] = useState<AnswerRecord[]>([]);
  const [streak, setStreak] = useState(0);
  const [maxStreak, setMaxStreak] = useState(0);

  const shuffledQuestions = useState(() => {
    if (!questions.length) return [];
    return [...questions].sort(() => Math.random() - 0.5);
  })[0];

  const currentQuestion = shuffledQuestions[currentIndex];
  const totalQuestions = Math.min(20, shuffledQuestions.length);
  const progress = ((currentIndex) / totalQuestions) * 100;

  const startQuiz = useCallback(() => {
    setPhase('playing');
    setCurrentIndex(0);
    setScore(0);
    setShowAnswer(false);
    setAnswers([]);
    setStreak(0);
    setMaxStreak(0);
  }, []);

  const revealAnswer = useCallback(() => {
    setShowAnswer(true);
    const newScore = score + 1;
    setScore(newScore);
    const newStreak = streak + 1;
    setStreak(newStreak);
    if (newStreak > maxStreak) setMaxStreak(newStreak);
    
    if (currentQuestion) {
      setAnswers(prev => [...prev, {
        questionId: currentQuestion.id,
        question: currentQuestion.question,
        answer: currentQuestion.answer,
        revealed: true
      }]);
    }
  }, [score, streak, maxStreak, currentQuestion]);

  const nextQuestion = useCallback(() => {
    if (currentIndex + 1 >= totalQuestions) {
      setPhase('results');
    } else {
      setCurrentIndex(prev => prev + 1);
      setShowAnswer(false);
    }
  }, [currentIndex, totalQuestions]);

  const skipQuestion = useCallback(() => {
    setStreak(0);
    if (currentQuestion) {
      setAnswers(prev => [...prev, {
        questionId: currentQuestion.id,
        question: currentQuestion.question,
        answer: currentQuestion.answer,
        revealed: false
      }]);
    }
    if (currentIndex + 1 >= totalQuestions) {
      setPhase('results');
    } else {
      setCurrentIndex(prev => prev + 1);
      setShowAnswer(false);
    }
  }, [currentIndex, totalQuestions, currentQuestion]);

  if (loading) return <div className="text-center py-12 text-slate-500">Загрузка...</div>;
  if (error) return <div className="text-center py-12 text-red-500">Ошибка: {error}</div>;

  // Ready Screen
  if (phase === 'ready') {
    return (
      <Card className="max-w-lg mx-auto">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Zap className="h-8 w-8 text-blue-600" />
          </div>
          <CardTitle className="text-2xl">Викторина ПМ08</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center space-y-2">
            <p className="text-slate-600">
              Проверьте свои знания по Интернету вещей!
            </p>
            <div className="flex justify-center gap-4 text-sm">
              <Badge variant="outline" className="gap-1">
                <BookOpen className="h-3 w-3" />
                {totalQuestions} вопросов
              </Badge>
              <Badge variant="outline" className="gap-1">
                <Eye className="h-3 w-3" />
                Открытые ответы
              </Badge>
            </div>
          </div>
          
          <div className="bg-slate-50 rounded-lg p-4 text-sm text-slate-600">
            <p className="font-semibold mb-2">Как играть:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Вам покажут вопрос - постарайтесь вспомнить ответ</li>
              <li>Нажмите &quot;Показать ответ&quot; чтобы проверить себя</li>
              <li>Используйте &quot;Пропустить&quot; если не знаете</li>
              <li>В конце увидите свою статистику</li>
            </ul>
          </div>

          <Button onClick={startQuiz} className="w-full gap-2 text-lg py-6">
            <Zap className="h-5 w-5" />
            Начать викторину!
          </Button>
        </CardContent>
      </Card>
    );
  }

  // Results Screen
  if (phase === 'results') {
    const percentage = Math.round((score / totalQuestions) * 100);
    const getGrade = () => {
      if (percentage >= 90) return { label: 'Отлично!', color: 'text-green-600', bg: 'bg-green-50' };
      if (percentage >= 70) return { label: 'Хорошо!', color: 'text-blue-600', bg: 'bg-blue-50' };
      if (percentage >= 50) return { label: 'Неплохо', color: 'text-amber-600', bg: 'bg-amber-50' };
      return { label: 'Попробуйте ещё', color: 'text-red-600', bg: 'bg-red-50' };
    };
    const grade = getGrade();

    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <Card>
          <CardHeader className="text-center">
            <div className={`w-20 h-20 ${grade.bg} rounded-full flex items-center justify-center mx-auto mb-4`}>
              <Trophy className={`h-10 w-10 ${grade.color}`} />
            </div>
            <CardTitle className="text-2xl">{grade.label}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-slate-50 rounded-lg p-4">
                <p className="text-3xl font-bold text-slate-800">{score}</p>
                <p className="text-sm text-slate-500">Ответов</p>
              </div>
              <div className="bg-slate-50 rounded-lg p-4">
                <p className="text-3xl font-bold text-slate-800">{percentage}%</p>
                <p className="text-sm text-slate-500">Результат</p>
              </div>
              <div className="bg-slate-50 rounded-lg p-4">
                <p className="text-3xl font-bold text-slate-800">{maxStreak}</p>
                <p className="text-sm text-slate-500">Рекорд</p>
              </div>
            </div>

            <Button onClick={startQuiz} className="w-full gap-2" variant="outline">
              <RotateCcw className="h-4 w-4" />
              Пройти ещё раз
            </Button>
          </CardContent>
        </Card>

        {/* Review Answers */}
        <div className="space-y-3">
          <h3 className="font-semibold text-lg">Обзор вопросов:</h3>
          {answers.map((a, i) => (
            <Card key={i} className={a.revealed ? 'border-green-200' : 'border-red-200'}>
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Badge variant={a.revealed ? 'default' : 'destructive'} className="mt-0.5">
                    {a.revealed ? <Star className="h-3 w-3" /> : '✗'}
                  </Badge>
                  <div>
                    <p className="font-medium text-sm">{a.question}</p>
                    <p className="text-sm text-slate-600 mt-1">{a.answer}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  // Playing Screen
  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Top Bar */}
      <div className="flex items-center justify-between bg-white p-3 rounded-lg border shadow-sm">
        <Badge variant="outline" className="gap-1">
          <Star className="h-3 w-3" />
          Серия: {streak}
        </Badge>
        <span className="text-sm text-slate-600">
          Вопрос {currentIndex + 1} из {totalQuestions}
        </span>
        <Badge variant="secondary">{score} отв.</Badge>
      </div>

      <Progress value={progress} className="h-2" />

      {/* Question Card */}
      <Card className="border-blue-200 shadow-lg">
        <CardHeader>
          <CardTitle className="text-lg leading-relaxed">
            {currentQuestion?.question}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!showAnswer ? (
            <div className="text-center py-8">
              <p className="text-slate-500 mb-4">Вспомните ответ и нажмите кнопку ниже</p>
            </div>
          ) : (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 animate-in fade-in slide-in-from-bottom-2">
              <p className="text-sm font-semibold text-green-800 mb-1">Ответ:</p>
              <p className="text-green-900 text-lg">{currentQuestion?.answer}</p>
            </div>
          )}

          <div className="flex gap-3">
            {!showAnswer ? (
              <>
                <Button
                  onClick={revealAnswer}
                  className="flex-1 gap-2 bg-green-600 hover:bg-green-700"
                  size="lg"
                >
                  <Eye className="h-4 w-4" />
                  Знаю ответ! (+1)
                </Button>
                <Button
                  onClick={skipQuestion}
                  variant="outline"
                  className="gap-2"
                  size="lg"
                >
                  <EyeOff className="h-4 w-4" />
                  Пропустить
                </Button>
              </>
            ) : (
              <Button
                onClick={nextQuestion}
                className="w-full gap-2"
                size="lg"
              >
                {currentIndex + 1 >= totalQuestions ? (
                  <>Результаты</>
                ) : (
                  <>
                    Далее
                    <ChevronRight className="h-4 w-4" />
                  </>
                )}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
