import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Trophy, RotateCcw, ChevronRight, Star, Zap, CheckCircle, XCircle } from 'lucide-react';
import { usePM10Questions } from '@/hooks/useQuestions';

type QuizPhase = 'ready' | 'playing' | 'answered' | 'results';

interface AnswerRecord {
  questionId: number;
  question: string;
  selectedOption: string;
  correctOption: string;
  isCorrect: boolean;
}

const OPTION_LABELS = ['A', 'B', 'C', 'D', 'E'];

export default function PM10Quiz() {
  const { questions, loading, error } = usePM10Questions();
  const [phase, setPhase] = useState<QuizPhase>('ready');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [answers, setAnswers] = useState<AnswerRecord[]>([]);
  const [streak, setStreak] = useState(0);
  const [maxStreak, setMaxStreak] = useState(0);

  const shuffledQuestions = useState(() => {
    if (!questions.length) return [];
    // Shuffle and shuffle options within each question
    return [...questions]
      .sort(() => Math.random() - 0.5)
      .map(q => {
        // Remember correct answer before shuffling
        const correctAnswer = q.options[q.correctIndex];
        const shuffledOptions = [...q.options].sort(() => Math.random() - 0.5);
        const newCorrectIndex = shuffledOptions.indexOf(correctAnswer);
        return {
          ...q,
          options: shuffledOptions,
          correctIndex: newCorrectIndex
        };
      });
  })[0];

  const currentQuestion = shuffledQuestions[currentIndex];
  const totalQuestions = Math.min(20, shuffledQuestions.length);
  const progress = ((currentIndex) / totalQuestions) * 100;

  const startQuiz = useCallback(() => {
    setPhase('playing');
    setCurrentIndex(0);
    setScore(0);
    setSelectedOption(null);
    setAnswers([]);
    setStreak(0);
    setMaxStreak(0);
  }, []);

  const selectOption = useCallback((idx: number) => {
    if (phase !== 'playing') return;
    setSelectedOption(idx);
    setPhase('answered');

    const isCorrect = idx === currentQuestion.correctIndex;
    if (isCorrect) {
      const newScore = score + 1;
      setScore(newScore);
      const newStreak = streak + 1;
      setStreak(newStreak);
      if (newStreak > maxStreak) setMaxStreak(newStreak);
    } else {
      setStreak(0);
    }

    setAnswers(prev => [...prev, {
      questionId: currentQuestion.id,
      question: currentQuestion.question,
      selectedOption: currentQuestion.options[idx],
      correctOption: currentQuestion.options[currentQuestion.correctIndex],
      isCorrect
    }]);
  }, [phase, currentQuestion, score, streak, maxStreak]);

  const nextQuestion = useCallback(() => {
    if (currentIndex + 1 >= totalQuestions) {
      setPhase('results');
    } else {
      setCurrentIndex(prev => prev + 1);
      setSelectedOption(null);
      setPhase('playing');
    }
  }, [currentIndex, totalQuestions]);

  if (loading) return <div className="text-center py-12 text-slate-500">Загрузка...</div>;
  if (error) return <div className="text-center py-12 text-red-500">Ошибка: {error}</div>;

  // Ready Screen
  if (phase === 'ready') {
    return (
      <Card className="max-w-lg mx-auto">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Zap className="h-8 w-8 text-emerald-600" />
          </div>
          <CardTitle className="text-2xl">Викторина ПМ10</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center space-y-2">
            <p className="text-slate-600">
              Проверьте знания сетевых технологий!
            </p>
            <div className="flex justify-center gap-4 text-sm">
              <Badge variant="outline" className="gap-1">
                {totalQuestions} вопросов
              </Badge>
              <Badge variant="outline" className="gap-1">
                Выбор ответа
              </Badge>
            </div>
          </div>
          
          <div className="bg-slate-50 rounded-lg p-4 text-sm text-slate-600">
            <p className="font-semibold mb-2">Как играть:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Выберите один правильный вариант ответа</li>
              <li>Сразу увидите, правильно ли ответили</li>
              <li>Соберите серию правильных ответов!</li>
              <li>В конце увидите полную статистику</li>
            </ul>
          </div>

          <Button onClick={startQuiz} className="w-full gap-2 text-lg py-6 bg-emerald-600 hover:bg-emerald-700">
            <Zap className="h-5 w-5" />
            Начать викторину!
          </Button>
        </CardContent>
      </Card>
    );
  }

  // Results Screen
  if (phase === 'results') {
    const percentage = Math.round((score / totalQuestions) * 100);
    const getGrade = () => {
      if (percentage >= 90) return { label: 'Отлично!', color: 'text-green-600', bg: 'bg-green-50' };
      if (percentage >= 70) return { label: 'Хорошо!', color: 'text-blue-600', bg: 'bg-blue-50' };
      if (percentage >= 50) return { label: 'Неплохо', color: 'text-amber-600', bg: 'bg-amber-50' };
      return { label: 'Попробуйте ещё', color: 'text-red-600', bg: 'bg-red-50' };
    };
    const grade = getGrade();

    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <Card>
          <CardHeader className="text-center">
            <div className={`w-20 h-20 ${grade.bg} rounded-full flex items-center justify-center mx-auto mb-4`}>
              <Trophy className={`h-10 w-10 ${grade.color}`} />
            </div>
            <CardTitle className="text-2xl">{grade.label}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="bg-slate-50 rounded-lg p-4">
                <p className="text-3xl font-bold text-slate-800">{score}/{totalQuestions}</p>
                <p className="text-sm text-slate-500">Правильно</p>
              </div>
              <div className="bg-slate-50 rounded-lg p-4">
                <p className="text-3xl font-bold text-slate-800">{percentage}%</p>
                <p className="text-sm text-slate-500">Результат</p>
              </div>
              <div className="bg-slate-50 rounded-lg p-4">
                <p className="text-3xl font-bold text-slate-800">{maxStreak}</p>
                <p className="text-sm text-slate-500">Лучшая серия</p>
              </div>
            </div>

            <Button onClick={startQuiz} className="w-full gap-2" variant="outline">
              <RotateCcw className="h-4 w-4" />
              Пройти ещё раз
            </Button>
          </CardContent>
        </Card>

        {/* Review Answers */}
        <div className="space-y-3">
          <h3 className="font-semibold text-lg">Обзор ответов:</h3>
          {answers.map((a, i) => (
            <Card key={i} className={a.isCorrect ? 'border-green-200' : 'border-red-200'}>
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  {a.isCorrect ? (
                    <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                  )}
                  <div className="flex-1">
                    <p className="font-medium text-sm">{a.question}</p>
                    {!a.isCorrect && (
                      <p className="text-sm text-red-600 mt-1 line-through">
                        Ваш ответ: {a.selectedOption}
                      </p>
                    )}
                    <p className="text-sm text-green-700 mt-1">
                      Правильно: {a.correctOption}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  // Playing / Answered Screen
  const isAnswered = phase === 'answered';

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Top Bar */}
      <div className="flex items-center justify-between bg-white p-3 rounded-lg border shadow-sm">
        <Badge variant="outline" className="gap-1">
          <Star className="h-3 w-3" />
          Серия: {streak}
        </Badge>
        <span className="text-sm text-slate-600">
          Вопрос {currentIndex + 1} из {totalQuestions}
        </span>
        <Badge variant="secondary">{score}/{totalQuestions}</Badge>
      </div>

      <Progress value={progress} className="h-2" />

      {/* Question Card */}
      <Card className="border-emerald-200 shadow-lg">
        <CardHeader>
          <CardTitle className="text-lg leading-relaxed">
            {currentQuestion?.question}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Options */}
          <div className="space-y-2">
            {currentQuestion?.options.map((option, idx) => {
              let buttonStyle = '';
              let icon = null;

              if (isAnswered) {
                if (idx === currentQuestion.correctIndex) {
                  buttonStyle = 'bg-green-100 border-green-400 text-green-800 hover:bg-green-100';
                  icon = <CheckCircle className="h-5 w-5 text-green-600" />;
                } else if (idx === selectedOption && idx !== currentQuestion.correctIndex) {
                  buttonStyle = 'bg-red-100 border-red-400 text-red-800 hover:bg-red-100';
                  icon = <XCircle className="h-5 w-5 text-red-500" />;
                } else {
                  buttonStyle = 'opacity-50';
                }
              }

              return (
                <Button
                  key={idx}
                  variant="outline"
                  className={`w-full justify-start gap-3 h-auto py-4 text-left ${buttonStyle}`}
                  onClick={() => selectOption(idx)}
                  disabled={isAnswered}
                >
                  <Badge variant={isAnswered && idx === currentQuestion.correctIndex ? 'default' : 'secondary'}>
                    {OPTION_LABELS[idx]}
                  </Badge>
                  <span className="flex-1">{option}</span>
                  {icon}
                </Button>
              );
            })}
          </div>

          {isAnswered && (
            <Button
              onClick={nextQuestion}
              className="w-full gap-2 mt-4"
              size="lg"
            >
              {currentIndex + 1 >= totalQuestions ? (
                <>Результаты</>
              ) : (
                <>
                  Далее
                  <ChevronRight className="h-4 w-4" />
                </>
              )}
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
