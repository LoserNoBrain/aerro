import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Clock, Upload, BookOpen } from 'lucide-react';

export default function PM09Placeholder() {
  return (
    <div className="space-y-6">
      <Card className="bg-amber-50 border-amber-200">
        <CardHeader>
          <CardTitle className="text-amber-800 flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Раздел в разработке
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-amber-700">
            Материалы для ПМ09 пока не загружены. Этот раздел будет заполнен после получения
            файла с вопросами и ответами по ПМ09.
          </p>
          
          <div className="bg-white rounded-lg p-4 border border-amber-200">
            <h3 className="font-semibold text-amber-800 mb-3 flex items-center gap-2">
              <Upload className="h-4 w-4" />
              Как добавить материалы:
            </h3>
            <ol className="list-decimal list-inside space-y-2 text-amber-700 text-sm">
              <li>Подготовьте файл .docx с вопросами и ответами по ПМ09</li>
              <li>Отправьте файл через чат</li>
              <li>Я интегрирую вопросы в этот раздел</li>
            </ol>
          </div>

          <div className="flex items-center gap-3 text-sm text-amber-600">
            <BookOpen className="h-4 w-4" />
            <span>После загрузки файла здесь появятся вопросы с поиском и викторина</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
