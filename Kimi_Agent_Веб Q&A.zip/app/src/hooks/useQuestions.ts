import { useState, useEffect } from 'react';
import type { PM08Question, PM10Question } from '@/types/questions';

export function usePM08Questions() {
  const [questions, setQuestions] = useState<PM08Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/data/pm08.json')
      .then(res => res.json())
      .then((data: PM08Question[]) => {
        setQuestions(data);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  return { questions, loading, error };
}

export function usePM10Questions() {
  const [questions, setQuestions] = useState<PM10Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/data/pm10.json')
      .then(res => res.json())
      .then((data: PM10Question[]) => {
        setQuestions(data);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, []);

  return { questions, loading, error };
}
